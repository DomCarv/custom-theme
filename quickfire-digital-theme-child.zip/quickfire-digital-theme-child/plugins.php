<?php
$plugins = array(
    array(
        'name'      => 'BuddyPress',
        'slug'      => 'buddypress',
        'required'  => false, // this plugin is recommended
    )

);